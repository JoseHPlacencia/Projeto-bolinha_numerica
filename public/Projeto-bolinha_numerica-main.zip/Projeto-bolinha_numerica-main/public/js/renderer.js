export function createCanvasRenderer(canvas, gameConfig) {
    const ctx = canvas.getContext("2d");
        
    const virtualWidth = gameConfig?.screen?.virtualWidth || 1920;
    const virtualHeight = gameConfig?.screen?.virtualHeight || 1080;
    const mapRadius = gameConfig?.world?.mapRadius || 1500;
    const playerSize = gameConfig?.world?.playerSize || 70;

    return {
        resizeCanvas,
        renderWorld,
        getDebugState
    };

    function resizeCanvas() {
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        
        const scale = Math.min(windowWidth / virtualWidth, windowHeight / virtualHeight);
        
        canvas.width = virtualWidth;
        canvas.height = virtualHeight;
        
        canvas.style.width = `${virtualWidth * scale}px`;
        canvas.style.height = `${virtualHeight * scale}px`;
    }

    function renderWorld(state, myId) {
        ctx.fillStyle = "#1e1e24";
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        if (!state) return;
        const players = state.players || {};
        const items = state.items || [];
        const me = players[myId];

        ctx.save();
        if (me && typeof me.x === "number" && typeof me.y === "number") {
            ctx.translate(canvas.width / 2 - me.x, canvas.height / 2 - me.y);
        } else {
            ctx.translate(canvas.width / 2, canvas.height / 2);
        }
        ctx.beginPath();
        ctx.arc(0, 0, mapRadius, 0, Math.PI * 2);
        ctx.strokeStyle = "#ff4a5a";
        ctx.lineWidth = 10;
        ctx.stroke();
        ctx.fillStyle = "#111116";
        ctx.fill();
        if (items && typeof items.forEach === "function") {
            items.forEach(item => {
                if (!item || typeof item.x !== "number" || typeof item.y !== "number") return;
                
                ctx.fillStyle = "#ffd166";
                ctx.beginPath();
                ctx.arc(item.x, item.y, 20, 0, Math.PI * 2);
                ctx.fill();

                ctx.fillStyle = "#000";
                ctx.font = "bold 16px sans-serif";
                ctx.textAlign = "center";
                ctx.textBaseline = "middle";
                ctx.fillText(item.value || "0", item.x, item.y);
            });
        }

        for (const id in players) {
            const p = players[id];
            if (!p || typeof p.x !== "number" || typeof p.y !== "number") {
                continue;
            }

            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.angle || 0);

            ctx.fillStyle = id === myId ? "#4cc9f0" : "#06d6a0";
            
            // Desenha a bolinha do jogador
            ctx.beginPath();
            ctx.arc(0, 0, playerSize / 2, 0, Math.PI * 2);
            ctx.fill();

            ctx.strokeStyle = "#ffffff";
            ctx.lineWidth = 5;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(playerSize / 2, 0);
            ctx.stroke();

            ctx.restore();
        }

        ctx.restore();
    }

    function getDebugState() {
        return {
            rendererType: "Canvas2D",
            dimensions: `${canvas.width}x${canvas.height}`
        };
    }
}