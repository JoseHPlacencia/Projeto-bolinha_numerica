export function drawItemsLayer(context, items) {
    for (const item of Object.values(items)) {
        drawNumericItem(context, item);
    }
}

function drawNumericItem(context, item) {
    context.save();
    context.translate(item.x, item.y);

    context.beginPath();
    context.arc(0, 0, 30, 0, Math.PI * 2);
    context.fillStyle = item.color;
    context.globalAlpha = 0.15;
    context.fill();

    context.beginPath();
    context.arc(0, 0, 30, 0, Math.PI * 2);
    context.strokeStyle = item.color;
    context.lineWidth = 2;
    context.globalAlpha = 0.6;
    context.stroke();

    context.globalAlpha = 1.0;
    context.font = "bold 22px Arial";
    context.fillStyle = "#000000";
    context.textAlign = "center";
    context.textBaseline = "middle";
    context.fillText(item.display, 0, -4);

    context.font = "12px Arial";
    context.fillStyle = item.color;
    context.fillText(item.type, 0, 16);

    context.restore();
}