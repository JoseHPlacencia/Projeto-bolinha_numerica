const { getServerTime } = require("../utils/time");

function createSnapshot(players, numericItems) { 
    return {
        time: getServerTime(),
        players: serializePlayers(players),
        items: serializeItems(numericItems) // Adicionado à foto da rede de 30Hz
    };
}

function serializePlayers(players) {
    const serializedPlayers = {};

    for (const player of players.values()) {
        serializedPlayers[player.id] = player.serialize();
    }

    return serializedPlayers;
}

// Função para varrer o mapa de números aleatórios e serializá-los para a rede
function serializeItems(numericItems) {
    const serializedItems = {};

    for (const item of numericItems.values()) {
        serializedItems[item.id] = item.serialize();
    }

    return serializedItems;
}

module.exports = {
    createSnapshot,
    serializePlayers
};