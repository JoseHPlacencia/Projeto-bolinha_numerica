const config = require("../config/gameConfig");
const { updatePlayers } = require("../systems/movementSystem");
const { updateItems } = require("../systems/itemSystem"); 
const { getHighResolutionTime } = require("../utils/time");

function startGameLoop(players, numericItems) { 
    
    const tickRate = config?.loop?.tickRate || 60;
    const intervalMs = 1000 / tickRate;
    
    const maxDelta = config?.loop?.maxDeltaTime || 0.1;
    let previousTime = getHighResolutionTime();

    return setInterval(() => {
        const now = getHighResolutionTime();
        const deltaTime = Math.min((now - previousTime) / 1000, maxDelta);
        previousTime = now;

        
        if (typeof updatePlayers === 'function') {
            updatePlayers(players, deltaTime);
        }

       
        if (typeof updateItems === 'function') {
            updateItems(numericItems, players);
        }
    }, intervalMs);
}

module.exports = startGameLoop;