const config = require("../config/gameConfig");

function registerSocket(io, players) {
    io.on("connection", (socket) => {
        console.log(`[REDE] Novo jogador conectado: ${socket.id}`);

        const mapRadius = config?.world?.mapRadius || 1500;
        
        const initialPlayer = {
            id: socket.id,
            x: 0, 
            y: 0,
            angle: 0,
            score: 0,
            directionAngle: null,
            lastAction: null,
            inputQueue: [] 
        };

        players.set(socket.id, initialPlayer);

        socket.on("playerInput", (inputData) => {
            const player = players.get(socket.id);
            if (player && player.inputQueue) {
                player.inputQueue.push(inputData);
            }
        });

        socket.on("disconnect", () => {
            console.log(`[REDE] Jogador desconectado: ${socket.id}`);
            players.delete(socket.id);
        });
    });
}

module.exports = registerSocket;