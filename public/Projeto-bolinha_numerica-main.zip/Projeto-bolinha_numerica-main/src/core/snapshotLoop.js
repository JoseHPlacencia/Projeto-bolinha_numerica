const config = require("../config/gameConfig");

function startSnapshotLoop(io, players, numericItems) {

    const snapshotRate = config?.loop?.snapshotRate || config?.server?.snapshotRate || 30;
    const intervalMs = 1000 / snapshotRate;

    return setInterval(() => {
        sendSnapshot(io, players, numericItems);
    }, intervalMs);
}

function sendSnapshot(io, players, numericItems) {

    const playersObj = {};
    players.forEach((player, id) => {
        playersObj[id] = {
            id: player.id || id,
            x: player.x,
            y: player.y,
            angle: player.angle || 0,
            score: player.score || 0
        };
    });
    const itemsArr = [];
    numericItems.forEach((item, id) => {
        itemsArr.push({
            id: id,
            x: item.x,
            y: item.y,
            value: item.value
        });
    });

    const packet = {
        time: Date.now(),
        players: playersObj,
        items: itemsArr
    };

    io.volatile.emit("gameState", packet);
}

module.exports = startSnapshotLoop;
module.exports.sendSnapshot = sendSnapshot;