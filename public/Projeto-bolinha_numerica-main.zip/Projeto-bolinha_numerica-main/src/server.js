const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const config = require("./config/gameConfig");

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
    pingInterval: config.network?.pingInterval || 10000,
    pingTimeout: config.network?.pingTimeout || 5000,
    transports: ["websocket", "polling"],
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    },
    allowEIO3: true,
    perMessageDeflate: false
});

app.use(express.static(path.join(__dirname, "../public")));


app.get("/game-config", (req, res) => {
    res.setHeader("Content-Type", "application/json");
    
    const fullConfig = {
        ...config,
        screen: config.screen || config.client?.screen || { minAspectRatio: 4/3, maxAspectRatio: 21/9, virtualWidth: 1920, virtualHeight: 1080 },
        world: config.world || config.client?.world,
        network: config.network || config.client?.network,
        client: {
            ...config.client,
            screen: config.client?.screen || config.screen,
            world: config.client?.world || config.world,
            network: config.client?.network || config.network
        }
    };
    
    res.json(fullConfig);
});

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "../public/index.html"));
});

const players = new Map();
const numericItems = new Map();

const registerSocket = require("./core/socketHandler");
const startGameLoop = require("./core/gameLoop");
const startSnapshotLoop = require("./core/snapshotLoop");

const runRegisterSocket = typeof registerSocket === 'function' ? registerSocket : registerSocket?.default || registerSocket;
const runGameLoop = typeof startGameLoop === 'function' ? startGameLoop : startGameLoop?.default || startGameLoop;
const runSnapshotLoop = typeof startSnapshotLoop === 'function' ? startSnapshotLoop : startSnapshotLoop?.default || startSnapshotLoop;

if (typeof runRegisterSocket === 'function') {
    runRegisterSocket(io, players); 
    console.log("-> Motor de rede (Socket) ativado com sucesso!");
} else {
    console.error("-> Erro crítico: Não foi possível carregar a função registerSocket.");
}

if (typeof runGameLoop === 'function') {
    runGameLoop(players, numericItems); 
    console.log("-> Loop de física do jogo iniciado!");
} else {
    console.error("-> Erro crítico: Não foi possível carregar o gameLoop.");
}

if (typeof runSnapshotLoop === 'function') {
    runSnapshotLoop(io, players, numericItems); 
    console.log("-> Envio de atualizações (Snapshots) ativado!");
} else {
    console.error("-> Erro crítico: Não foi possível carregar o snapshotLoop.");
}
const PORT = config.server?.port || 3000;
server.listen(PORT, () => {
    console.log(`\n==================================================`);
    console.log(`Server running at http://localhost:3000`);
    console.log(`==================================================`);
});