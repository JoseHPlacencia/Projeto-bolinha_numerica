const { createSpawn } = require("../systems/spawnSystem");

const NUMBER_TYPES = Object.freeze({
    NATURAL: "N",
    INTEGER: "Z",
    RATIONAL: "Q",
    IRRATIONAL: "I",
    REAL: "R"
});

class NumericItem {
    constructor(id, players) {
        this.id = id;
        
        // Usa o spawnSystem existente para não nascer colado nas bases dos players
        const spawn = createSpawn(players);
        this.x = spawn.x;
        this.y = spawn.y;
        
        const info = generateRandomNumber();
        this.value = info.value;       // Valor matemático (ex: 1.4142...)
        this.display = info.display;   // Texto que aparece na tela (ex: "√2")
        this.type = info.type;         // Letra do conjunto numérico
        this.color = info.color;       // Cor característica do conjunto
    }

    serialize() {
        return {
            id: this.id,
            x: this.x,
            y: this.y,
            display: this.display,
            type: this.type,
            color: this.color
        };
    }
}

function generateRandomNumber() {
    const types = Object.values(NUMBER_TYPES);
    const chosenType = types[Math.floor(Math.random() * types.length)];

    switch (chosenType) {
        case NUMBER_TYPES.NATURAL: {
            const val = Math.floor(Math.random() * 100);
            return { value: val, display: String(val), type: "ℕ", color: "#4caf50" }; // Verde
        }
        case NUMBER_TYPES.INTEGER: {
            const val = Math.floor(Math.random() * 199) - 99;
            if (val >= 0) return { value: val, display: String(val), type: "ℕ", color: "#4caf50" }; // N está contido em Z
            return { value: val, display: String(val), type: "ℤ", color: "#2196f3" }; // Azul
        }
        case NUMBER_TYPES.RATIONAL: {
            const num = Math.floor(Math.random() * 19) - 9;
            const den = Math.floor(Math.random() * 8) + 2; // Evita divisão por 0 e 1
            return { value: num / den, display: `${num}/${den}`, type: "ℚ", color: "#ff9800" }; // Laranja
        }
        case NUMBER_TYPES.IRRATIONAL: {
            const irrationals = [
                { value: Math.PI, display: "π" },
                { value: Math.E, display: "e" },
                { value: Math.sqrt(2), display: "√2" },
                { value: Math.sqrt(3), display: "√3" },
                { value: Math.sqrt(5), display: "√5" }
            ];
            const chosen = irrationals[Math.floor(Math.random() * irrationals.length)];
            return { ...chosen, type: "𝕀", color: "#9c27b0" }; // Roxo
        }
        case NUMBER_TYPES.REAL:
        default: {
            // Qualquer número real aleatório com ponto flutuante
            const val = (Math.random() * 200 - 100).toFixed(2);
            return { value: parseFloat(val), display: String(val), type: "ℝ", color: "#e91e63" }; // Rosa
        }
    }
}

function createNumericItem(items, id, players) {
    const item = new NumericItem(id, players);
    items.set(id, item);
    return item;
}

module.exports = {
    createNumericItem,
    NUMBER_TYPES
};