const config = require("../config/gameConfig");
const {
    addVectors,
    clamp,
    createMovementVector,
    dotProduct,
    lerpAngle,
    scaleVector,
    vectorLength
} = require("../utils/math");

function updatePlayers(players, deltaTime) {
    for (const player of players.values()) {
        processPlayerInputQueue(player);
        updatePlayer(player, deltaTime);
    }
}

function processPlayerInputQueue(player) {
    if (!player.inputQueue || player.inputQueue.length === 0) {
        return;
    }

    while (player.inputQueue.length > 0) {
        const inputData = player.inputQueue.shift();
        if (!inputData) continue;

        if (inputData.action) {
            player.lastAction = inputData.action;
            if (config.inputActionAngles && config.inputActionAngles[inputData.action] !== undefined) {
                player.directionAngle = config.inputActionAngles[inputData.action];
            }
        } else if (typeof inputData.angle === "number") {
            player.directionAngle = inputData.angle;
        }
    }
}

function updatePlayer(player, deltaTime) {
    rotatePlayerToLastInput(player, deltaTime);
    movePlayer(player, deltaTime);
}

function rotatePlayerToLastInput(player, deltaTime) {
    const targetAngle = getPlayerTargetAngle(player);
    if (targetAngle === null) return;

    player.angle = lerpAngle(
        player.angle,
        targetAngle,
        getRotationBlend(deltaTime)
    );
}

function getPlayerTargetAngle(player) {
    if (Number.isFinite(player.directionAngle)) {
        return player.directionAngle;
    }
    if (!player.lastAction || !hasInputAngle(player.lastAction)) {
        return null;
    }
    return config.inputActionAngles[player.lastAction];
}

function hasInputAngle(action) {
    return Object.prototype.hasOwnProperty.call(config.inputActionAngles, action);
}

function getRotationBlend(deltaTime) {
    const elapsedTicks = deltaTime * (config?.loop?.tickRate || 60);
    const blend = 1 - Math.pow(1 - (config?.movement?.rotationStrength || 0.1), elapsedTicks);
    return clamp(blend, 0, 1);
}

function movePlayer(player, deltaTime) {
    const targetAngle = getPlayerTargetAngle(player);
    if (targetAngle === null) return; 

    const movementVector = createMovementVector(targetAngle, config.movement.speed, deltaTime);
    const nextState = resolveMapBoundary(player, movementVector);

    player.x = nextState.x;
    player.y = nextState.y;
}

function resolveMapBoundary(player, movementVector) {
    const position = getPlayerPosition(player);
    const nextPosition = addVectors(position, movementVector);
    const distanceFromCenter = vectorLength(nextPosition);
    const mapLimit = getMapMovementLimit();

    if (distanceFromCenter <= mapLimit) {
        return { x: nextPosition.x, y: nextPosition.y };
    }

    return resolveSlidingBoundary(player, movementVector, nextPosition, distanceFromCenter);
}

function resolveSlidingBoundary(player, movementVector, nextPosition, distanceFromCenter) {
    const wallNormal = scaleVector(nextPosition, 1 / distanceFromCenter);
    const wallPush = dotProduct(movementVector, wallNormal);
    let slidingVector = movementVector;

    if (wallPush > 0) {
        slidingVector = {
            x: movementVector.x - wallPush * wallNormal.x,
            y: movementVector.y - wallPush * wallNormal.y
        };
    }

    return clampPositionToMap(addVectors(getPlayerPosition(player), slidingVector));
}

function clampPositionToMap(position) {
    const mapLimit = getMapMovementLimit();
    const distanceFromCenter = vectorLength(position) || 1;

    if (distanceFromCenter <= mapLimit) {
        return { x: position.x, y: position.y };
    }

    const scale = mapLimit / distanceFromCenter;
    return {
        x: position.x * scale,
        y: position.y * scale
    };
}

function getMapMovementLimit() {
    return (config?.world?.mapRadius || 1500) - (config?.world?.playerSize || 70) / 2;
}

function getPlayerPosition(player) {
    return {
        x: player.x || 0,
        y: player.y || 0
    };
}

module.exports = {
    getPlayerMovementVector: null,
    getPlayerTargetAngle,
    updatePlayer,
    updatePlayers
};