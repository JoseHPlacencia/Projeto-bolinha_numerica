const config = require("../config/gameConfig");
const { createNumericItem } = require("../entities/numericItem");

// Podemos colocar esse limite no gameConfig depois, ex: 30 itens simultâneos
const MAX_ITEMS = 30; 
let nextItemId = 0;

function updateItems(items, players) {
    // Se faltarem itens no mapa, gera novos até atingir o teto
    while (items.size < MAX_ITEMS) {
        const id = `item_${nextItemId++}`;
        createNumericItem(items, id, players);
    }

    // Aqui futuramente entrará a lógica de colisão (Teoria dos Conjuntos):
    // checkCollisions(players, items);
}

module.exports = {
    updateItems
};